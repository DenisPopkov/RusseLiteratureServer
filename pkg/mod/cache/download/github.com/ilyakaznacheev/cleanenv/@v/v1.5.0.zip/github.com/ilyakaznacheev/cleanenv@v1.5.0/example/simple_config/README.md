# Simple config

Example of simple web server reading configuration from the config file and environment variables.

In this example, some fields are not stored in the default configuration file (`config.yml`) by security reasons. Store passwords and other sensitive parameters in secure storage and read them from environment variables.