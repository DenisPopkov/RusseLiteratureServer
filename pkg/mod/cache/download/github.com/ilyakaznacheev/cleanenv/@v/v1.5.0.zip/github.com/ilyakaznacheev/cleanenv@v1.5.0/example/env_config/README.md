# Configuration from environment variables

In this example, a configuration is created from environment values, using different supported types.
