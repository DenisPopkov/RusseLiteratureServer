# Parse multiple files for configuration

This example shows how the package can be used to read from mutiple configuration files and assign them to the same structure.

In this example, the configuration is read from ```db_config.yaml```,```email_config.yaml``` and ```general_config.yaml``` and the values are stored in the ```config``` struct.